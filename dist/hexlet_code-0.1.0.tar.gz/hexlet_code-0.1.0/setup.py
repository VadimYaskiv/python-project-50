# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff',
 'gendiff.comparison',
 'gendiff.formatters',
 'gendiff.scripts',
 'gendiff.tests']

package_data = \
{'': ['*'],
 'gendiff': ['json_files/*', 'yaml_files/*'],
 'gendiff.tests': ['fixtures/*']}

install_requires = \
['pyyaml>=5.4.1,<6.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### CodeClimate tests and status:\n[![Maintainability](https://api.codeclimate.com/v1/badges/bf71ead1321a0c6c9379/maintainability)](https://codeclimate.com/github/VadimYaskiv/python-project-50/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/bf71ead1321a0c6c9379/test_coverage)](https://codeclimate.com/github/VadimYaskiv/python-project-50/test_coverage)\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/VadimYaskiv/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/VadimYaskiv/python-project-50/actions)\n\n### Linter test:\n[![linter-check](https://github.com/VadimYaskiv/python-project-50/actions/workflows/linter.yml/badge.svg)](https://github.com/VadimYaskiv/python-project-50/actions/workflows/linter.yml)\n\n### asciinema. step 3. flat json files comparison\n<a href="https://asciinema.org/a/b1EXOJLv7i7ZoBE4mMWZ29ivQ" target="_blank"><img src="https://asciinema.org/a/b1EXOJLv7i7ZoBE4mMWZ29ivQ.svg" /></a>\n\n### asciinema. step 5. flat yaml files comparison\n<a href="https://asciinema.org/a/FiaOKmKhzkbT7LUwd9mR1G1Pa" target="_blank"><img src="https://asciinema.org/a/FiaOKmKhzkbT7LUwd9mR1G1Pa.svg" /></a>\n\n### asciinema. step 6. recursive file comparison and output of result\n<a href="https://asciinema.org/a/4FyOgDgBXDM084L16SuSvWv0s" target="_blank"><img src="https://asciinema.org/a/4FyOgDgBXDM084L16SuSvWv0s.svg" /></a>',
    'author': 'Vadim',
    'author_email': 'vadimyaskiv89@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/VadimYaskiv/python-project-50',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
