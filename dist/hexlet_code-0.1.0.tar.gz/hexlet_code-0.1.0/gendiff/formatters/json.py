import json


def stringify_j(value):
    return json.dumps(value, indent=2)
