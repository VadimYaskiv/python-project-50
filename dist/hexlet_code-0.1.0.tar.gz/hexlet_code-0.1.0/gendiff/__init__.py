from gendiff.scripts.gendiff import main as generate_diff


__all__ = ('generate_diff')
