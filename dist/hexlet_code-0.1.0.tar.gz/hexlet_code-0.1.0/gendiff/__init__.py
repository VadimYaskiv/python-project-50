from gendiff.comparison.gendiff_logic import generate_diff


__all__ = ('generate_diff', )
