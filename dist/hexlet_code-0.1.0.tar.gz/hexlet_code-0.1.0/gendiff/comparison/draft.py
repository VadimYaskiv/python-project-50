

def ffff(val):
    val = str(val).lower()
    return val
print(ffff(False))